import React from 'react'
import type { Metadata } from 'next'

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: 'Бидний тухай — Сүхбаатарын Өнгө',
  description: 'Сүхбаатарын Өнгө сонины тухай мэдээлэл. Ерөнхий редактор Д.Улаанхүүхэн.',
}

export default function AboutPage() {
  return (
    <>
      <div className="page-hero">
        <div className="container">
          <h1>Бидний тухай</h1>
        </div>
      </div>
      <div className="container" style={{ maxWidth: 780 }}>
        <div style={{ background: 'var(--bg-white)', border: '1px solid var(--border)', borderRadius: 4, padding: '2rem', marginBottom: '2rem' }}>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: '1.5rem', marginBottom: '1rem' }}>
            Сүхбаатарын Өнгө сонин
          </h2>
          <p style={{ lineHeight: 1.8, marginBottom: '1rem', color: 'var(--text-muted)' }}>
             Сүхбаатарын өнгө сонин нь 2017 оноос эхлэн тогтмол гарч байна.
          </p>
          <p style={{ lineHeight: 1.8, marginBottom: '1rem', color: 'var(--text-muted)' }}>
            Аймгийнхаа 13 сум 67 багт хүрдэг. 14 хоног тутамд хэвлэгддэг.
          </p>
          <p style={{ lineHeight: 1.8, color: 'var(--text-muted)' }}>
            2024 оны МСНЭ-ийн "Ган үзэг" наадмын "Шилдэг сонин"-оор шалгарсан.
          </p>
        </div>

        <div style={{ background: 'var(--bg-white)', border: '1px solid var(--border)', borderRadius: 4, padding: '2rem', marginBottom: '2rem' }}>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: '1.5rem', marginBottom: '1rem' }}>
            Эрхлэгч
          </h2>
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
            <div style={{
              width: 80, height: 80, background: 'var(--accent)', borderRadius: '50%',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontFamily: 'var(--font-serif)', fontSize: '1.5rem', fontWeight: 700, flexShrink: 0,
            }}>
              Д
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-serif)', fontSize: '1.2rem', fontWeight: 700, marginBottom: '0.25rem' }}>
                Д.Улаанхүүхэн
              </div>
            </div>
          </div>
        </div>

        <div id="contact" style={{ background: 'var(--bg-white)', border: '1px solid var(--border)', borderRadius: 4, padding: '2rem', marginBottom: '2rem' }}>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: '1.5rem', marginBottom: '1.25rem' }}>
            Холбоо барих
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
              <span style={{ width: 24, color: 'var(--accent)', fontWeight: 700 }}>📞</span>
              <a href="tel:+97690099027" style={{ color: 'var(--text-muted)' }}>
                9009-9027
              </a>
            </div>
            <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
              <span style={{ width: 24, color: 'var(--accent)', fontWeight: 700 }}>📍</span>
              <span style={{ color: 'var(--text-muted)' }}>
                Монгол улс, Сүхбаатар аймаг, Баруун-Урт сум
              </span>
            </div>
            <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
              <span style={{ width: 24, color: 'var(--accent)', fontWeight: 700 }}>📘</span>
              <a
                href="https://facebook.com/sukhbaatar.ungu"
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: '#1877f2', fontWeight: 600 }}
              >
                facebook.com/sukhbaatar.ungu
              </a>
            </div>
          </div>
        </div>

        <div style={{ background: 'var(--accent)', color: '#fff', borderRadius: 4, padding: '1.5rem', textAlign: 'center' }}>
          <p style={{ fontSize: '0.95rem', lineHeight: 1.6 }}>
            Манай Facebook хуудсанд дагаж, орон нутгийн сонин мэдээнүүдийг тогтмол хүлээн авна уу.
          </p>
          <a
            href="https://facebook.com/sukhbaatar.ungu"
            target="_blank"
            rel="noopener noreferrer"
            style={{ display: 'inline-block', marginTop: '1rem', background: '#fff', color: 'var(--accent)', padding: '0.5rem 1.5rem', borderRadius: 4, fontWeight: 700, fontSize: '0.9rem' }}
          >
            Facebook дагах
          </a>
        </div>
      </div>
    </>
  )
}
